// www/indexeddb.js

console.log("Iniciando indexeddb.js...");

// Inicializar Dexie para IndexedDB
const db = new Dexie("SIPEIN_DB");
db.version(1).stores({
  sitios: "++CODSIT, NOMSIT, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  especies: "++CODESP, Nombre_Comun, Nombre_Cientifico, Subgrupo_ID, Clasificacion_ID, Constante_A, Constante_B, Clase_Medida, Clasificacion_Comercial, Grupo, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  estados: "++CODEST, NOMEST, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  clasifica: "++CODCLA, NOMCLA, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  grupos: "++CODGRU, NOMGRU, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  subgrupo: "++CODSUBGRU, NOMSUBGRU, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  arte: "++CODART, NOMART, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  metodo: "++CODMET, NOMMET, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  propulsion: "++CODPRO, NOMPRO, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  area: "++CODARE, NOMARE, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  subarea: "++CODSUBARE, NOMSUBARE, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  registrador: "++CODREG, NOMREG, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  embarcaciones: "++CODEMB, NOMEMB, Matricula, Potencia, Propulsion, Numero_Motores, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  gastos: "++CODGAS, NOMGAS, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  valor_mensual_gastos: "++ID, Gasto_ID, Ano, Mes, Valor, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  trm_dolar: "++ID, Fecha, Valor, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  faena_principal: "++ID, Registro, Fecha_Zarpe, Fecha_Arribo, Sitio_Desembarque, Subarea, Registrador, Embarcacion, Pescadores, Hora_Salida, Hora_Arribo, Horario, Galones, Estado_Verificacion, Verificado_Por, Fecha_Verificacion, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  detalles_captura: "++ID, Faena_ID, Especie_ID, Estado, Indv, Peso, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado",
  costos_operacion: "++ID, Faena_ID, Gasto_ID, Valor, Creado_Por, Fecha_Creacion, Modificado_Por, Fecha_Modificacion, Sincronizado"
});

// Cargar datos iniciales al iniciar la página
document.addEventListener("DOMContentLoaded", async () => {
  try {
    console.log("indexeddb.js cargado correctamente. Eliminando y recreando la base de datos...");
    await db.delete();
    console.log("Base de datos eliminada.");
    await db.open();
    console.log("Base de datos recreada.");

    // Datos iniciales para sitios
    const initialSitios = [
      { CODSIT: "SIT01", NOMSIT: "Puerto Principal", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 },
      { CODSIT: "SIT02", NOMSIT: "Bahía Secundaria", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 }
    ];
    if (await db.sitios.count() === 0) {
      await db.sitios.bulkAdd(initialSitios);
      console.log("Datos iniciales de sitios agregados.");
    }

    // Datos iniciales para subgrupo
    const initialSubgrupo = [
      { CODSUBGRU: "SUB01", NOMSUBGRU: "Peces Pelágicos", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 },
      { CODSUBGRU: "SUB02", NOMSUBGRU: "Peces Demersales", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 }
    ];
    if (await db.subgrupo.count() === 0) {
      await db.subgrupo.bulkAdd(initialSubgrupo);
      console.log("Datos iniciales de subgrupo agregados.");
    }

    // Datos iniciales para clasifica
    const initialClasifica = [
      { CODCLA: "CLA01", NOMCLA: "Comercial", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 },
      { CODCLA: "CLA02", NOMCLA: "No Comercial", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 }
    ];
    if (await db.clasifica.count() === 0) {
      await db.clasifica.bulkAdd(initialClasifica);
      console.log("Datos iniciales de clasifica agregados.");
    }

    // Datos iniciales para gastos
    const initialGastos = [
      { CODGAS: "GAS01", NOMGAS: "Combustible", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 },
      { CODGAS: "GAS02", NOMGAS: "Alimentos", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 }
    ];
    if (await db.gastos.count() === 0) {
      await db.gastos.bulkAdd(initialGastos);
      console.log("Datos iniciales de gastos agregados.");
    }

    // Datos iniciales para subarea
    const initialSubarea = [
      { CODSUBARE: "SUB01", NOMSUBARE: "Zona Norte", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 },
      { CODSUBARE: "SUB02", NOMSUBARE: "Zona Sur", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 }
    ];
    if (await db.subarea.count() === 0) {
      await db.subarea.bulkAdd(initialSubarea);
      console.log("Datos iniciales de subarea agregados.");
    }

    // Datos iniciales para registrador
    const initialRegistrador = [
      { CODREG: "REG01", NOMREG: "Juan Pérez", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 },
      { CODREG: "REG02", NOMREG: "María Gómez", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 }
    ];
    if (await db.registrador.count() === 0) {
      await db.registrador.bulkAdd(initialRegistrador);
      console.log("Datos iniciales de registrador agregados.");
    }

    // Datos iniciales para embarcaciones
    const initialEmbarcaciones = [
      { CODEMB: "EMB01", NOMEMB: "Barco 1", Matricula: "ABC123", Potencia: 500, Propulsion: "Motor", Numero_Motores: 1, Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 },
      { CODEMB: "EMB02", NOMEMB: "Barco 2", Matricula: "XYZ789", Potencia: 750, Propulsion: "Motor", Numero_Motores: 2, Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 }
    ];
    if (await db.embarcaciones.count() === 0) {
      await db.embarcaciones.bulkAdd(initialEmbarcaciones);
      console.log("Datos iniciales de embarcaciones agregados.");
    }

    // Datos iniciales para especies (añadido para consistencia con pruebas anteriores)
    const initialEspecies = [
      { CODESP: "ESP01", Nombre_Comun: "Sardina", Nombre_Cientifico: "Sardina pilchardus", Subgrupo_ID: "SUB01", Clasificacion_ID: "CLA01", Constante_A: 0.01, Constante_B: 0.02, Clase_Medida: "cm", Clasificacion_Comercial: "Rojo", Grupo: "Pez", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 },
      { CODESP: "ESP02", Nombre_Comun: "Atún", Nombre_Cientifico: "Thunnus albacares", Subgrupo_ID: "SUB01", Clasificacion_ID: "CLA01", Constante_A: 0.015, Constante_B: 0.025, Clase_Medida: "cm", Clasificacion_Comercial: "Rojo", Grupo: "Pez", Creado_Por: "system", Fecha_Creacion: new Date().toISOString(), Modificado_Por: "system", Fecha_Modificacion: new Date().toISOString(), Sincronizado: 0 }
    ];
    if (await db.especies.count() === 0) {
      await db.especies.bulkAdd(initialEspecies);
      console.log("Datos iniciales de especies agregados.");
    }

  } catch (error) {
    console.error("Error al inicializar IndexedDB:", error);
  }

  // Escuchar mensajes personalizados desde el servidor Shiny
  Shiny.addCustomMessageHandler("update", function(moduleId) {
    console.log("Recibido mensaje de actualización para módulo: ", moduleId);
    if (moduleId === "ref_tables") {
      Shiny.setInputValue("ref_tables-ref_table_output", Date.now());
    } else if (moduleId === "ingreso_datos") {
      Shiny.setInputValue("ingreso_datos-faena_table", Date.now());
      Shiny.setInputValue("ingreso_datos-faena_form", Date.now());
    }
  });
});

// Cargar opciones dinámicas para los select
async function loadSelectOptions() {
  try {
    const subgrupos = await db.subgrupo.toArray();
    const clasificaciones = await db.clasifica.toArray();
    const gastos = await db.gastos.toArray();
    const sitios = await db.sitios.toArray();
    const subareas = await db.subarea.toArray();
    const registradores = await db.registrador.toArray();
    const embarcaciones = await db.embarcaciones.toArray();

    return {
      subgrupos: subgrupos.map(s => ({ value: s.CODSUBGRU, label: s.NOMSUBGRU })),
      clasificaciones: clasificaciones.map(c => ({ value: c.CODCLA, label: c.NOMCLA })),
      gastos: gastos.map(g => ({ value: g.CODGAS, label: g.NOMGAS })),
      sitios: sitios.map(s => ({ value: s.CODSIT, label: s.NOMSIT })),
      subareas: subareas.map(sa => ({ value: sa.CODSUBARE, label: sa.NOMSUBARE })),
      registradores: registradores.map(r => ({ value: r.CODREG, label: r.NOMREG })),
      embarcaciones: embarcaciones.map(e => ({ value: e.CODEMB, label: e.NOMEMB }))
    };
  } catch (error) {
    console.error("Error al cargar opciones dinámicas:", error);
    return {};
  }
}

// Manejar el mensaje saveData para guardar en IndexedDB
Shiny.addCustomMessageHandler("saveData", async function(message) {
  try {
    console.log("Recibido mensaje saveData:", message);
    const { table, data } = message;
    await db[table].put(data);
    console.log(`Datos guardados en ${table}:`, data);
    // Forzar recarga de la tabla después de guardar
    loadTableData(table);
  } catch (error) {
    console.error("Error al guardar datos en IndexedDB:", error);
  }
});

// Cargar datos de la tabla desde IndexedDB
Shiny.addCustomMessageHandler("loadTableData", function(message) {
  try {
    const table = message.table;
    db[table].toArray().then(data => {
      console.log(`Datos cargados de ${table}:`, data);
      Shiny.setInputValue("ref_table_output_data", data);
    }).catch(error => {
      console.error(`Error al cargar datos de ${table}:`, error);
    });
  } catch (error) {
    console.error("Error en loadTableData:", error);
  }
});

// Mostrar formulario para agregar/editar datos
Shiny.addCustomMessageHandler("showForm", async function(message) {
  try {
    const table = message.table;
    const action = message.action;
    const selectedRow = message.selectedRow;

    let rowData = {};
    if (action === "edit" && selectedRow !== -1) {
      rowData = await db[table].get(selectedRow);
    }

    const options = await loadSelectOptions();

    let formHtml = "";
    if (table === "sitios") {
      formHtml = `
        <div>
          <input id="sitios_CODSIT" placeholder="Código" value="${action === 'edit' ? rowData.CODSIT : ''}">
          <input id="sitios_NOMSIT" placeholder="Nombre" value="${action === 'edit' ? rowData.NOMSIT : ''}">
          <button onclick="saveForm('sitios')">Aceptar</button>
          <button onclick="cancelForm()">Cancelar</button>
          <div id="error_message" style="color: red;"></div>
        </div>
      `;
    } else if (table === "especies") {
      const subgrupoOptions = options.subgrupos.map(opt => 
        `<option value="${opt.value}" ${action === 'edit' && rowData.Subgrupo_ID === opt.value ? 'selected' : ''}>${opt.label}</option>`
      ).join('');
      const clasificacionOptions = options.clasificaciones.map(opt => 
        `<option value="${opt.value}" ${action === 'edit' && rowData.Clasificacion_ID === opt.value ? 'selected' : ''}>${opt.label}</option>`
      ).join('');

      formHtml = `
        <div>
          <input id="especies_CODESP" placeholder="Código" value="${action === 'edit' ? rowData.CODESP : ''}">
          <input id="especies_Nombre_Comun" placeholder="Nombre Común" value="${action === 'edit' ? rowData.Nombre_Comun : ''}">
          <input id="especies_Nombre_Cientifico" placeholder="Nombre Científico" value="${action === 'edit' ? rowData.Nombre_Cientifico : ''}">
          <select id="especies_Subgrupo_ID">
            <option value="">Seleccione un subgrupo</option>
            ${subgrupoOptions}
          </select>
          <select id="especies_Clasificacion_ID">
            <option value="">Seleccione una clasificación</option>
            ${clasificacionOptions}
          </select>
          <input id="especies_Constante_A" type="number" step="0.0000001" placeholder="Constante A" value="${action === 'edit' ? rowData.Constante_A : 0}">
          <input id="especies_Constante_B" type="number" step="0.0000001" placeholder="Constante B" value="${action === 'edit' ? rowData.Constante_B : 0}">
          <select id="especies_Clase_Medida">
            <option value="cm" ${action === 'edit' && rowData.Clase_Medida === 'cm' ? 'selected' : ''}>cm</option>
            <option value="mm" ${action === 'edit' && rowData.Clase_Medida === 'mm' ? 'selected' : ''}>mm</option>
          </select>
          <select id="especies_Clasificacion_Comercial">
            <option value="Rojo" ${action === 'edit' && rowData.Clasificacion_Comercial === 'Rojo' ? 'selected' : ''}>Rojo</option>
            <option value="Negro" ${action === 'edit' && rowData.Clasificacion_Comercial === 'Negro' ? 'selected' : ''}>Negro</option>
          </select>
          <input id="especies_Grupo" placeholder="Grupo" value="${action === 'edit' ? rowData.Grupo : ''}">
          <button onclick="saveForm('especies')">Aceptar</button>
          <button onclick="cancelForm()">Cancelar</button>
          <div id="error_message" style="color: red;"></div>
        </div>
      `;
    } else if (table === "valor_mensual_gastos") {
      const gastoOptions = options.gastos.map(opt => 
        `<option value="${opt.value}" ${action === 'edit' && rowData.Gasto_ID === opt.value ? 'selected' : ''}>${opt.label}</option>`
      ).join('');

      formHtml = `
        <div>
          <select id="vmg_Gasto_ID">
            <option value="">Seleccione un gasto</option>
            ${gastoOptions}
          </select>
          <input id="vmg_Ano" type="number" placeholder="Año" value="${action === 'edit' ? rowData.Ano : 2025}" min="2000" max="2100">
          <select id="vmg_Mes">
            ${[...Array(12).keys()].map(i => {
              const month = i + 1;
              return `<option value="${month}" ${action === 'edit' && rowData.Mes === month ? 'selected' : ''}>${month}</option>`;
            }).join('')}
          </select>
          <input id="vmg_Valor" type="number" step="0.01" placeholder="Precio ($)" value="${action === 'edit' ? rowData.Valor : 0}">
          <button onclick="saveForm('valor_mensual_gastos')">Aceptar</button>
          <button onclick="cancelForm()">Cancelar</button>
          <div id="error_message" style="color: red;"></div>
        </div>
      `;
    } else if (table === "faena_principal") {
      const sitioOptions = options.sitios.map(opt => 
        `<option value="${opt.value}" ${action === 'edit' && rowData.Sitio_Desembarque === opt.value ? 'selected' : ''}>${opt.label}</option>`
      ).join('');
      const subareaOptions = options.subareas.map(opt => 
        `<option value="${opt.value}" ${action === 'edit' && rowData.Subarea === opt.value ? 'selected' : ''}>${opt.label}</option>`
      ).join('');
      const registradorOptions = options.registradores.map(opt => 
        `<option value="${opt.value}" ${action === 'edit' && rowData.Registrador === opt.value ? 'selected' : ''}>${opt.label}</option>`
      ).join('');
      const embarcacionOptions = options.embarcaciones.map(opt => 
        `<option value="${opt.value}" ${action === 'edit' && rowData.Embarcacion === opt.value ? 'selected' : ''}>${opt.label}</option>`
      ).join('');

      formHtml = `
        <div>
          <input id="faena_Registro" placeholder="Registro" value="${action === 'edit' ? rowData.Registro : ''}">
          <input id="faena_Fecha_Zarpe" type="date" value="${action === 'edit' ? rowData.Fecha_Zarpe : ''}">
          <input id="faena_Fecha_Arribo" type="date" value="${action === 'edit' ? rowData.Fecha_Arribo : ''}">
          <select id="faena_Sitio_Desembarque">
            <option value="">Seleccione un sitio</option>
            ${sitioOptions}
          </select>
          <select id="faena_Subarea">
            <option value="">Seleccione una subárea</option>
            ${subareaOptions}
          </select>
          <select id="faena_Registrador">
            <option value="">Seleccione un registrador</option>
            ${registradorOptions}
          </select>
          <select id="faena_Embarcacion">
            <option value="">Seleccione una embarcación</option>
            ${embarcacionOptions}
          </select>
          <input id="faena_Pescadores" type="number" min="0" placeholder="Pescadores" value="${action === 'edit' ? rowData.Pescadores : 0}">
          <input id="faena_Hora_Salida" type="time" value="${action === 'edit' ? rowData.Hora_Salida : '08:00'}">
          <input id="faena_Hora_Arribo" type="time" value="${action === 'edit' ? rowData.Hora_Arribo : '16:00'}">
          <select id="faena_Horario">
            <option value="DIA" ${action === 'edit' && rowData.Horario === 'DIA' ? 'selected' : ''}>DIA</option>
            <option value="NOCHE" ${action === 'edit' && rowData.Horario === 'NOCHE' ? 'selected' : ''}>NOCHE</option>
          </select>
          <input id="faena_Galones" type="number" min="0" step="0.1" placeholder="Galones" value="${action === 'edit' ? rowData.Galones : 0}">
          <button onclick="saveForm('faena_principal')">Aceptar</button>
          <button onclick="cancelForm()">Cancelar</button>
          <div id="error_message" style="color: red;"></div>
        </div>
      `;
    } else {
      formHtml = `
        <div>
          <input id="generic_ID" placeholder="Código" value="${action === 'edit' ? rowData[Object.keys(rowData)[0]] : ''}">
          <input id="generic_Nombre" placeholder="Nombre" value="${action === 'edit' ? rowData[Object.keys(rowData)[1]] : ''}">
          <button onclick="saveForm('${table}')">Aceptar</button>
          <button onclick="cancelForm()">Cancelar</button>
          <div id="error_message" style="color: red;"></div>
        </div>
      `;
    }

    document.getElementById("ref_form_ui").innerHTML = formHtml;
  } catch (error) {
    console.error("Error al mostrar formulario:", error);
  }
});

// Función para validar datos antes de guardar
async function validateForm(table) {
  let errors = [];
  let data = {};

  try {
    if (table === "sitios") {
      const CODSIT = document.getElementById("sitios_CODSIT").value;
      const NOMSIT = document.getElementById("sitios_NOMSIT").value;

      if (!CODSIT) errors.push("El código es obligatorio.");
      if (!NOMSIT) errors.push("El nombre es obligatorio.");

      const count = await db.sitios.where("CODSIT").equals(CODSIT).count();
      if (count > 0 && action !== "edit") errors.push("El código ya existe.");

      data = {
        CODSIT: CODSIT,
        NOMSIT: NOMSIT,
        Creado_Por: "system",
        Fecha_Creacion: new Date().toISOString(),
        Modificado_Por: "system",
        Fecha_Modificacion: new Date().toISOString(),
        Sincronizado: 0
      };
    } else if (table === "especies") {
      const CODESP = document.getElementById("especies_CODESP").value;
      const Nombre_Comun = document.getElementById("especies_Nombre_Comun").value;
      const Nombre_Cientifico = document.getElementById("especies_Nombre_Cientifico").value;
      const Subgrupo_ID = document.getElementById("especies_Subgrupo_ID").value;
      const Clasificacion_ID = document.getElementById("especies_Clasificacion_ID").value;
      const Constante_A = parseFloat(document.getElementById("especies_Constante_A").value) || 0;
      const Constante_B = parseFloat(document.getElementById("especies_Constante_B").value) || 0;
      const Clase_Medida = document.getElementById("especies_Clase_Medida").value;
      const Clasificacion_Comercial = document.getElementById("especies_Clasificacion_Comercial").value;
      const Grupo = document.getElementById("especies_Grupo").value;

      if (!CODESP) errors.push("El código es obligatorio.");
      if (!Nombre_Comun) errors.push("El nombre común es obligatorio.");
      if (!Nombre_Cientifico) errors.push("El nombre científico es obligatorio.");
      if (!Subgrupo_ID) errors.push("El subgrupo es obligatorio.");
      if (!Clasificacion_ID) errors.push("La clasificación es obligatorio.");

      const count = await db.especies.where("CODESP").equals(CODESP).count();
      if (count > 0 && action !== "edit") errors.push("El código ya existe.");

      data = {
        CODESP: CODESP,
        Nombre_Comun: Nombre_Comun,
        Nombre_Cientifico: Nombre_Cientifico,
        Subgrupo_ID: Subgrupo_ID,
        Clasificacion_ID: Clasificacion_ID,
        Constante_A: Constante_A,
        Constante_B: Constante_B,
        Clase_Medida: Clase_Medida,
        Clasificacion_Comercial: Clasificacion_Comercial,
        Grupo: Grupo,
        Creado_Por: "system",
        Fecha_Creacion: new Date().toISOString(),
        Modificado_Por: "system",
        Fecha_Modificacion: new Date().toISOString(),
        Sincronizado: 0
      };
    } else if (table === "valor_mensual_gastos") {
      const Gasto_ID = document.getElementById("vmg_Gasto_ID").value;
      const Ano = parseInt(document.getElementById("vmg_Ano").value) || 2025;
      const Mes = parseInt(document.getElementById("vmg_Mes").value) || 1;
      const Valor = parseFloat(document.getElementById("vmg_Valor").value) || 0;

      if (!Gasto_ID) errors.push("El gasto es obligatorio.");
      if (Ano < 2000 || Ano > 2100) errors.push("El año debe estar entre 2000 y 2100.");

      data = {
        Gasto_ID: Gasto_ID,
        Ano: Ano,
        Mes: Mes,
        Valor: Valor,
        Creado_Por: "system",
        Fecha_Creacion: new Date().toISOString(),
        Modificado_Por: "system",
        Fecha_Modificacion: new Date().toISOString(),
        Sincronizado: 0
      };
    } else if (table === "faena_principal") {
      const Registro = document.getElementById("faena_Registro").value;
      const Fecha_Zarpe = document.getElementById("faena_Fecha_Zarpe").value;
      const Fecha_Arribo = document.getElementById("faena_Fecha_Arribo").value;
      const Sitio_Desembarque = document.getElementById("faena_Sitio_Desembarque").value;
      const Subarea = document.getElementById("faena_Subarea").value;
      const Registrador = document.getElementById("faena_Registrador").value;
      const Embarcacion = document.getElementById("faena_Embarcacion").value;
      const Pescadores = parseInt(document.getElementById("faena_Pescadores").value) || 0;
      const Hora_Salida = document.getElementById("faena_Hora_Salida").value;
      const Hora_Arribo = document.getElementById("faena_Hora_Arribo").value;
      const Horario = document.getElementById("faena_Horario").value;
      const Galones = parseFloat(document.getElementById("faena_Galones").value) || 0;

      if (!Registro) errors.push("El registro es obligatorio.");
      if (!Fecha_Zarpe) errors.push("La fecha de zarpe es obligatoria.");
      if (!Fecha_Arribo) errors.push("La fecha de arribo es obligatoria.");
      if (!Sitio_Desembarque) errors.push("El sitio de desembarque es obligatorio.");
      if (!Subarea) errors.push("La subárea es obligatoria.");
      if (!Registrador) errors.push("El registrador es obligatorio.");
      if (!Embarcacion) errors.push("La embarcación es obligatoria.");
      if (!Hora_Salida) errors.push("La hora de salida es obligatoria.");
      if (!Hora_Arribo) errors.push("La hora de arribo es obligatoria.");

      const count = await db.faena_principal.where("Registro").equals(Registro).count();
      if (count > 0 && action !== "edit") errors.push("El registro ya existe.");

      data = {
        Registro: Registro,
        Fecha_Zarpe: Fecha_Zarpe,
        Fecha_Arribo: Fecha_Arribo,
        Sitio_Desembarque: Sitio_Desembarque,
        Subarea: Subarea,
        Registrador: Registrador,
        Embarcacion: Embarcacion,
        Pescadores: Pescadores,
        Hora_Salida: Hora_Salida,
        Hora_Arribo: Hora_Arribo,
        Horario: Horario,
        Galones: Galones,
        Estado_Verificacion: "Pendiente",
        Verificado_Por: "",
        Fecha_Verificacion: "",
        Creado_Por: "system",
        Fecha_Creacion: new Date().toISOString(),
        Modificado_Por: "system",
        Fecha_Modificacion: new Date().toISOString(),
        Sincronizado: 0
      };
    } else {
      const ID = document.getElementById("generic_ID").value;
      const Nombre = document.getElementById("generic_Nombre").value;

      if (!ID) errors.push("El código es obligatorio.");
      if (!Nombre) errors.push("El nombre es obligatorio.");

      const count = await db[table].where("ID").equals(ID).count();
      if (count > 0 && action !== "edit") errors.push("El código ya existe.");

      data = {
        ID: ID,
        Nombre: Nombre,
        Creado_Por: "system",
        Fecha_Creacion: new Date().toISOString(),
        Modificado_Por: "system",
        Fecha_Modificacion: new Date().toISOString(),
        Sincronizado: 0
      };
    }
  } catch (error) {
    console.error("Error al validar formulario:", error);
    errors.push("Error al validar los datos.");
  }

  return { errors, data };
}

// Función para guardar datos en IndexedDB
async function saveForm(table) {
  try {
    const { errors, data } = await validateForm(table);

    if (errors.length > 0) {
      document.getElementById("error_message").innerHTML = errors.join("<br>");
      return;
    }

    await db[table].put(data);
    console.log(`Datos guardados desde formulario en ${table}:`, data);
    loadTableData(table);
    document.getElementById("ref_form_ui").innerHTML = "";
  } catch (error) {
    console.error("Error al guardar datos desde formulario:", error);
    document.getElementById("error_message").innerHTML = "Error al guardar los datos.";
  }
}

// Función para cancelar
function cancelForm() {
  document.getElementById("ref_form_ui").innerHTML = "";
}

// Cargar datos de la tabla
function loadTableData(table) {
  db[table].toArray().then(data => {
    console.log(`Datos recargados para ${table} después de guardar:`, data);
    Shiny.setInputValue("ref_table_output_data", data);
  }).catch(error => {
    console.error(`Error al recargar datos de ${table}:`, error);
  });
}

// Sincronización con PostgreSQL
Shiny.addCustomMessageHandler("syncData", function(message) {
  if (navigator.onLine) {
    const tables = ["sitios", "especies", "estados", "clasifica", "grupos", "subgrupo", "arte", "metodo", "propulsion", "area", "subarea", "registrador", "embarcaciones", "gastos", "valor_mensual_gastos", "trm_dolar", "faena_principal", "detalles_captura", "costos_operacion"];
    tables.forEach(table => {
      db[table].where("Sincronizado").equals(0).toArray().then(data => {
        data.forEach(row => {
          fetch('http://localhost:8001/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ table: table, data: row })
          }).then(response => response.json()).then(result => {
            if (result.success) {
              db[table].update(row[Object.keys(row)[0]], { Sincronizado: 1 });
              console.log(`Datos sincronizados para ${table}:`, row);
            } else if (result.conflict) {
              Shiny.setInputValue("conflict_detected", {
                table: table,
                local: result.local,
                central: result.central
              });
              console.log("Conflicto detectado:", result);
            }
          }).catch(err => console.error(`Error al sincronizar ${table}:`, err));
        });
      }).catch(error => {
        console.error(`Error al consultar datos para sincronizar en ${table}:`, error);
      });
    });
  } else {
    console.log("No hay conexión a internet para sincronizar.");
  }
});

// Actualizar estado de sincronización en IndexedDB
Shiny.addCustomMessageHandler("updateSyncStatus", function(message) {
  try {
    const { table, id, Sincronizado } = message;
    db[table].update(id, { Sincronizado: Sincronizado });
    console.log(`Estado de sincronización actualizado para ${table}, ID: ${id}`);
  } catch (error) {
    console.error("Error al actualizar estado de sincronización:", error);
  }
});

// Actualizar IndexedDB con datos de PostgreSQL
Shiny.addCustomMessageHandler("updateIndexedDB", function(message) {
  try {
    const { table, data } = message;
    db[table].put(data);
    console.log(`IndexedDB actualizado para ${table}:`, data);
  } catch (error) {
    console.error("Error al actualizar IndexedDB:", error);
  }
});

console.log("indexeddb.js cargado completamente.");