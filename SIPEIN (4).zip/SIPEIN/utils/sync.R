# utils/sync.R

# (Vacío por ahora, ya que la sincronización se maneja en api.R)