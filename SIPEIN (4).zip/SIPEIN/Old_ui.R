# ui.R

library(shiny)
library(shinymanager)

ui <- secure_app(
  tags$head(
    tags$script(src = "dexie.min.js"),
    tags$script(src = "indexeddb.js"),
    tags$link(rel = "stylesheet", type = "text/css", href = "styles.css")
  ),
  fluidPage(
    titlePanel("SIPEIN - Sistema de Información Pesquera"),
    
    # Contenido estático para depuración
    h2("¡Bienvenido a SIPEIN!"),
    p("Si ves este texto, la UI se está renderizando correctamente."),

    # Botón de sincronización
    actionButton("sync_btn", "Sincronizar", icon = icon("sync")),
    textOutput("sync_status"),
    
    # Sección para resolver conflictos
    uiOutput("conflict_resolution_ui"),
    
    # Menú de navegación (simplificado)
    sidebarLayout(
      sidebarPanel(
        selectInput("module", "Seleccione un módulo:",
                    choices = c("Tablas de Referencia", "Ingreso de Datos")),
        conditionalPanel(
          condition = "input.module == 'Tablas de Referencia'",
          selectInput("ref_table", "Seleccionar tabla:",
                      choices = c("Sitios de Desembarque", "Especies Comerciales"))
        ),
        conditionalPanel(
          condition = "input.module == 'Ingreso de Datos'",
          selectInput("ingreso_submodule", "Seleccionar submódulo:",
                      choices = c("Captura y Esfuerzo"))
        )
      ),
      
      mainPanel(
        # Contenido estático en lugar de uiOutput
        h3("Contenido de prueba"),
        p("Este es un texto de prueba para el mainPanel.")
      )
    )
  )
)