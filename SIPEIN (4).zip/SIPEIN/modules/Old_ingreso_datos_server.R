# modules/ingreso_datos_server.R

library(shiny)
library(DT)

ingreso_datos_server <- function(id, central_conn, submodule) {
  moduleServer(id, function(input, output, session) {
    faena_data <- reactiveVal()
    
    observe({
      message("Solicitando datos de faena_principal...")
      session$sendCustomMessage("loadTableData", list(table = "faena_principal"))
    })
    
    observeEvent(input$ref_table_output_data, {
      message("Datos recibidos en ingreso_datos_server: ", toString(input$ref_table_output_data))
      if (!is.null(input$ref_table_output_data) && input$ref_table_output_data$table == "faena_principal") {
        faena_data(input$ref_table_output_data$data)
      }
    })
    
    output$faena_table <- renderDT({
      message("Renderizando tabla en ingreso_datos_server...")
      data <- faena_data()
      if (is.null(data) || length(data) == 0) {
        datatable(data.frame(Test = c("Faena 1", "Faena 2")), options = list(pageLength = 5))
      } else {
        datatable(as.data.frame(data), options = list(pageLength = 5))
      }
    })
    
    output$faena_form <- renderUI({
      message("Renderizando formulario en ingreso_datos_server...")
      tagList(
        h4("Ingreso de Datos de Faena"),
        textInput("registro_input", "Registro"),
        dateInput("fecha_zarpe_input", "Fecha de Zarpe", value = Sys.Date()),
        dateInput("fecha_arribo_input", "Fecha de Arribo", value = Sys.Date()),
        selectInput("sitio_select", "Sitio de Desembarque", choices = c("Sitio 1", "Sitio 2")),
        selectInput("subarea_select", "Subárea de Pesca", choices = c("Subárea 1", "Subárea 2")),
        selectInput("registrador_select", "Registrador", choices = c("Registrador 1", "Registrador 2")),
        selectInput("embarcacion_select", "Embarcación", choices = c("Embarcación 1", "Embarcación 2")),
        numericInput("pescadores_input", "Número de Pescadores", value = 1, min = 1),
        textInput("hora_salida_input", "Hora de Salida", placeholder = "HH:MM"),
        textInput("hora_arribo_input", "Hora de Arribo", placeholder = "HH:MM"),
        selectInput("horario_select", "Horario", choices = c("Diurno", "Nocturno")),
        numericInput("galones_input", "Galones Consumidos", value = 0, min = 0),
        actionButton("save_button", "Guardar", icon = icon("save"))
      )
    })
    
    observeEvent(input$save_button, {
      new_data <- list(
        Registro = input$registro_input,
        Fecha_Zarpe = as.character(input$fecha_zarpe_input),
        Fecha_Arribo = as.character(input$fecha_arribo_input),
        Sitio_Desembarque = input$sitio_select,
        Subarea = input$subarea_select,
        Registrador = input$registrador_select,
        Embarcacion = input$embarcacion_select,
        Pescadores = as.integer(input$pescadores_input),
        Hora_Salida = input$hora_salida_input,
        Hora_Arribo = input$hora_arribo_input,
        Horario = input$horario_select,
        Galones = as.numeric(input$galones_input),
        Estado_Verificacion = "Pendiente",
        Verificado_Por = "",
        Fecha_Verificacion = "",
        Creado_Por = "system",
        Fecha_Creacion = as.character(Sys.time()),
        Modificado_Por = "system",
        Fecha_Modificacion = as.character(Sys.time()),
        Sincronizado = 0
      )
      session$sendCustomMessage("saveData", list(table = "faena_principal", data = new_data))
      session$sendCustomMessage("loadTableData", list(table = "faena_principal"))
    })
    
    return(list(
      save_data = function(data) {},
      edit_data = function(row) {}
    ))
  })
}