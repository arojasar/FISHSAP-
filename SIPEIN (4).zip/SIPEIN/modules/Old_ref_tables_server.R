# modules/ref_tables_server.R

library(shiny)
library(DT)

ref_tables_server <- function(id, central_conn, table_name) {
  moduleServer(id, function(input, output, session) {
    db <- reactiveValues(data = NULL)
    
    table_map <- list(
      "Sitios de Desembarque" = "sitios_desembarque",
      "Especies Comerciales" = "especies",
      "Categorías de Estado" = "categorias_estado",
      "Clasificación" = "clasificacion",
      "Grupos" = "grupos",
      "Subgrupos" = "subgrupos",
      "Artes de Pesca" = "artes_pesca",
      "Método de Técnica de Pesca" = "metodo_tecnica_pesca",
      "Métodos de Propulsión" = "metodos_propulsion",
      "Área de Pesca" = "area_pesca",
      "Subárea de Pesca" = "subarea_pesca",
      "Registradores de Campo" = "registradores_campo",
      "Embarcaciones" = "embarcaciones",
      "Gastos de Faena" = "gastos_faena",
      "Valor Mensual de los Gastos" = "valor_mensual_gastos",
      "TRM (Dólar)" = "trm_dolar"
    )
    
    check_internet <- function() {
      !is.null(curl::nslookup("google.com", error = FALSE))
    }
    
    observe({
      selected_table <- table_name()
      if (!is.null(selected_table) && selected_table %in% names(table_map)) {
        table_key <- table_map[[selected_table]]
        if (!is.null(table_key) && check_internet() && !is.null(central_conn)) {
          session$sendCustomMessage("loadTableData", list(table = table_key))
        }
      }
    })
    
    observeEvent(input$ref_table_output_data, {
      message("Datos recibidos en ref_tables_server: ", toString(input$ref_table_output_data))
      db$data <- input$ref_table_output_data
    })
    
    output$ref_table_output <- renderDT({
      message("Renderizando tabla en ref_tables_server...")
      if (is.null(db$data) || length(db$data) == 0) {
        datatable(data.frame(Test = c("Dato 1", "Dato 2")), options = list(pageLength = 5))
      } else {
        datatable(as.data.frame(db$data), options = list(pageLength = 5))
      }
    })
  })
}